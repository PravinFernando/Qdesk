import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../services/storage_service.dart';

class ReimbursementScreen extends StatefulWidget {
  const ReimbursementScreen({super.key});

  @override
  State<ReimbursementScreen> createState() =>
      _ReimbursementScreenState();
}

class _ReimbursementScreenState
    extends State<ReimbursementScreen> {

  final _formKey = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final employeeIdController = TextEditingController();
  final descriptionController = TextEditingController();
  final assignmentController = TextEditingController();
  final amountController = TextEditingController();

  String reimbursementType = "Food";

  DateTime selectedDate = DateTime.now();

  File? selectedImage;

  bool isLoading = false;

  final List<String> reimbursementTypes = [
    "Food",
    "Travel",
    "Accommodation",
    "Fuel",
    "Other"
  ];

  Future pickImage() async {
    final picked =
    await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );

    if (picked == null) return;

    setState(() {
      selectedImage = File(picked.path);
    });
  }

  Future<String> uploadImage() async {

    if (selectedImage == null) {
      return "";
    }

    try {

      final fileName =
      DateTime.now().millisecondsSinceEpoch.toString();

      final ref = FirebaseStorage.instance
          .ref()
          .child("receipts")
          .child("$fileName.jpg");

      // Upload image
      UploadTask uploadTask =
      ref.putFile(selectedImage!);

      // Wait for upload completion
      TaskSnapshot snapshot =
      await uploadTask;

      // Get download URL
      String downloadUrl =
      await snapshot.ref.getDownloadURL();

      return downloadUrl;

    } catch (e) {

      print("UPLOAD ERROR: $e");

      return "";
    }
  }

  Future submitReimbursement() async {

    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {

      final uid =
          FirebaseAuth.instance.currentUser!.uid;

      //final imageUrl = await uploadImage();
      final storageService = StorageService();

      final imageUrl =
      await storageService.uploadReceipt();

      await FirebaseFirestore.instance
          .collection("reimbursements")
          .add({

        "uid": uid,

        "name": nameController.text.trim(),

        "employeeId":
        employeeIdController.text.trim(),

        "reimbursementType":
        reimbursementType,

        "expenseDate":
        selectedDate
            .toString()
            .substring(0, 10),

        "description":
        descriptionController.text.trim(),

        "assignmentName":
        assignmentController.text.trim(),

        "amount":
        double.parse(amountController.text),

        "imageUrl": imageUrl,

        "status": "pending",

        "createdAt":
        FieldValue.serverTimestamp(),

        "reviewedBy": null,
        "reviewedAt": null,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content:
          Text("Reimbursement Submitted"),
        ),
      );

      Navigator.pop(context);

    } catch (e) {

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );

    }

    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text("Reimbursement"),
      ),

      body: SingleChildScrollView(

        padding: const EdgeInsets.all(20),

        child: Form(

          key: _formKey,

          child: Column(

            children: [

              TextFormField(
                controller: nameController,
                decoration:
                const InputDecoration(
                  labelText: "Name",
                ),
                validator: (value) =>
                value!.isEmpty
                    ? "Enter name"
                    : null,
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller:
                employeeIdController,
                decoration:
                const InputDecoration(
                  labelText: "Employee ID",
                ),
                validator: (value) =>
                value!.isEmpty
                    ? "Enter Employee ID"
                    : null,
              ),

              const SizedBox(height: 15),

              DropdownButtonFormField(

                value: reimbursementType,

                items: reimbursementTypes
                    .map(
                      (type) => DropdownMenuItem(
                    value: type,
                    child: Text(type),
                  ),
                )
                    .toList(),

                onChanged: (value) {

                  setState(() {
                    reimbursementType =
                    value!;
                  });

                },

                decoration:
                const InputDecoration(
                  labelText:
                  "Type of Reimbursement",
                ),
              ),

              const SizedBox(height: 15),

              ListTile(

               // tileColor: Colors.grey,

                title: Text(
                  "Expense Date: "
                      "${selectedDate.toString().substring(0, 10)}",
                ),

                trailing:
                const Icon(Icons.calendar_month),

                onTap: () async {

                  final picked =
                  await showDatePicker(

                    context: context,

                    initialDate: selectedDate,

                    firstDate:
                    DateTime(2024),

                    lastDate:
                    DateTime.now(),

                  );

                  if (picked != null) {

                    setState(() {
                      selectedDate = picked;
                    });

                  }
                },
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller:
                descriptionController,
                maxLines: 3,
                decoration:
                const InputDecoration(
                  labelText: "Description",
                ),
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller:
                assignmentController,
                decoration:
                const InputDecoration(
                  labelText:
                  "Assignment Name (College)",
                ),
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller:
                amountController,
                keyboardType:
                TextInputType.number,
                decoration:
                const InputDecoration(
                  labelText: "Amount in Rs",
                ),
                validator: (value) =>
                value!.isEmpty
                    ? "Enter amount"
                    : null,
              ),

              const SizedBox(height: 20),

              ElevatedButton.icon(

                onPressed: pickImage,

                icon: const Icon(Icons.upload),

                label:
                const Text("Upload Receipt"),

              ),

              const SizedBox(height: 10),

              if (selectedImage != null)

                Image.file(
                  selectedImage!,
                  height: 150,
                ),

              const SizedBox(height: 30),

              SizedBox(

                width: double.infinity,

                child: ElevatedButton(

                  onPressed:
                  isLoading
                      ? null
                      : submitReimbursement,

                  child: isLoading
                      ? const CircularProgressIndicator()
                      : const Text(
                    "Submit Reimbursement",
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}