import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class MyReimbursements extends StatelessWidget {
  const MyReimbursements({super.key});

  @override
  Widget build(BuildContext context) {

    final uid =
        FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(

      appBar: AppBar(
        title:
        const Text("My Reimbursements"),
      ),

      body: StreamBuilder(

        stream: FirebaseFirestore.instance
            .collection("reimbursements")
            .where("uid", isEqualTo: uid)
            .snapshots(),

        builder: (context, snapshot) {

          if (!snapshot.hasData) {

            return const Center(
              child:
              CircularProgressIndicator(),
            );
          }

          final docs =
              snapshot.data!.docs;

          if (docs.isEmpty) {

            return const Center(
              child: Text(
                "No reimbursements found",
              ),
            );
          }

          return ListView.builder(

            itemCount: docs.length,

            itemBuilder: (context, index) {

              final data = docs[index];

              return Card(

                margin:
                const EdgeInsets.all(12),

                child: ListTile(

                  title: Text(
                    data["reimbursementType"],
                  ),

                  subtitle: Column(

                    crossAxisAlignment:
                    CrossAxisAlignment.start,

                    children: [

                      Text(
                        "₹${data["amount"]}",
                      ),

                      Text(
                        data["expenseDate"],
                      ),

                      Text(
                        data["assignmentName"],
                      ),
                    ],
                  ),

                  trailing: Container(

                    padding:
                    const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),

                    decoration: BoxDecoration(

                      color:
                      data["status"] ==
                          "approved"
                          ? Colors.green
                          : data["status"] ==
                          "rejected"
                          ? Colors.red
                          : Colors.orange,

                      borderRadius:
                      BorderRadius.circular(
                        20,
                      ),
                    ),

                    child: Text(

                      data["status"]
                          .toUpperCase(),

                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight:
                        FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}